# QianWindow
<BR>使用Qt5.14.2编译 or Qt5.15一键编译
<BR>已经测试windows/linux多平台编译完成
<BR>最新版本视频地址： <a href="https://space.bilibili.com/82157618/channel/seriesdetail?sid=3264958&ctype=0">B站演示入口</a>

## Linux编译部分截图
![image](preview/linux.png)

## Windows编译部分截图
![image](preview/windwos.png)
