#ifndef CONFIG_H
#define CONFIG_H

#define WIDTH 500
#define HEIGHT 400

#define CENTER_X 200
#define CENTER_Y 150

#define ENEMY_NUM 50
#define TREE_NUM 50

#endif // CONFIG_H
