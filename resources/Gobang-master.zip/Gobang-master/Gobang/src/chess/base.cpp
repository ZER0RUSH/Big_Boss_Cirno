#include "base.h"

ChessType reverse(ChessType typeIn) {
    return ChessType(-1 * typeIn);
}
