#include "chatinput.h"

ChatInput::ChatInput()
{

}
